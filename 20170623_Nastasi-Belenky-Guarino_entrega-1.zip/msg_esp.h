
#define MSG_ERROR_PREFIX "Error:"
#define MSG_NO_MEM "Hubo un error al utilizar memoria"
#define MSG_NULL_POINTER "Error al intentar acceder a puntero nulo"

