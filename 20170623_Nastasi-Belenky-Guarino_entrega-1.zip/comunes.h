#ifndef COMUNES__H
#define COMUNES__H

#include "types.h"
void handleError(status_t);

#endif