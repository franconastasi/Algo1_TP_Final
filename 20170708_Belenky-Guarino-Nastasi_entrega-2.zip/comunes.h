#ifndef COMUNES__H
#define COMUNES__H

#define MAX_CANT_DATOS 32
#define MAX_VALOR_DATO 100

#include "types.h"
void handle_error(status_t);

#endif